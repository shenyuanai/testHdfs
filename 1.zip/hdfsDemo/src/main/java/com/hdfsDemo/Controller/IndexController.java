package com.hdfsDemo.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class IndexController {
	@RequestMapping("/upload")
	@ResponseBody
	public String testHdfs() throws IOException, InterruptedException, URISyntaxException {
		System.out.println("进来了");
		Configuration config=new Configuration();
		config.set("fs.defaultFS", "hdfs://192.168.121.130:9000");
		FileSystem hdfs=FileSystem.get(new URI("hdfs://192.168.121.130:9000"),config,"master");
		File f=new File("d:/a.txt");
		
		Path srcPath=new Path(f.getPath());
		Path destPath=new Path("/data");
		hdfs.copyFromLocalFile(srcPath, destPath);
		hdfs.close();
		return "";
	}
	@RequestMapping("/mkdir")
	@ResponseBody
	public String testMkdir() throws IOException, InterruptedException, URISyntaxException {
		Configuration config=new Configuration();
		config.set("fs.defaultFS", "hdfs://192.168.121.130:9000");
		FileSystem hdfs=FileSystem.get(new URI("hdfs://192.168.121.130:9000"),config,"master");
		Path destDir=new Path("/20190317");
		
		boolean b=hdfs.mkdirs(destDir);
		if(b) {
			return "ok";
		}else {
			return "fuck";
		}
	}
	@RequestMapping("/readFile")
	@ResponseBody
	public String readFile() throws IOException, InterruptedException, URISyntaxException {
		Configuration config=new Configuration();
		config.set("fs.defaultFS", "hdfs://192.168.121.130:9000");
		FileSystem hdfs=FileSystem.get(new URI("hdfs://192.168.121.130:9000"),config,"master");
		Path destDir=new Path("/data/a.txt");
		InputStream in;
		in=hdfs.open(destDir);
		int n=-1;
		StringBuffer sb=new StringBuffer("");
		byte [] b=new byte[1024];
		while((n=in.read(b, 0, 1024))!=-1) {
			String s=new String(b,0,n);
			System.out.println(s);
			sb.append(s);
		}
		return sb.toString();
		}
}

