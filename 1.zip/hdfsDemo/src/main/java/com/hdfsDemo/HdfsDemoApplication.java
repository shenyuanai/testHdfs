package com.hdfsDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HdfsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HdfsDemoApplication.class, args);
	}

}
